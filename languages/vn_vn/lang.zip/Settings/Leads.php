<?php
/*+***********************************************************************************
 * The contents of this file are subject to the vtiger CRM Public License Version 1.0
 * ("License"); You may not use this file except in compliance with the License
 * The Original Code is:  vtiger CRM Open Source
 * The Initial Developer of the Original Code is vtiger.
 * Portions created by vtiger are Copyright (C) vtiger.
 * All Rights Reserved.
 *************************************************************************************/
/**
 * Modified by: Kelvin Thang 
 * Date: 2018-06-26
 */
$languageStrings = array(
	//Actions
	'LBL_CONVERT_LEAD_FIELD_MAPPING' => 'Thiết lập dữ liệu để chuyển đổi Lead',
	'LBL_ORGANIZATIONS' => 'Khách hàng',
	'LBL_CONTACTS' => 'Liên hệ',
	'LBL_OPPURTUNITIES' => 'Cơ hội',
);
$jsLanguageStrings = array(
);
