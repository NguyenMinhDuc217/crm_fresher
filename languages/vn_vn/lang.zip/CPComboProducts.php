<?php

/* System auto-generated on 2020-04-19 02:09:03 pm.  */

$languageStrings = array(
    'CPComboProducts' => 'Gói sản phẩm',
    'SINGLE_CPComboProducts' => 'Gói sản phẩm',
    'ModuleName ID' => 'Gói sản phẩm ID',
    'LBL_ADD_RECORD' => 'Thêm Gói sản phẩm',
    'LBL_RECORDS_LIST' => 'Danh sách Gói sản phẩm',
    'LBL_GENERAL_INFORMATION' => 'Thông tin chung',
    'LBL_TRACKING_INFOMATION' => 'Thông tin mô tả',
    'LBL_NAME' => 'Tên',
    'LBL_DESCRIPTION' => 'Mô tả',
    'LBL_MODIFIED_TIME' => 'Ngày sửa',
    'LBL_ASSIGNED_TO' => 'Giao cho',
    'LBL_CREATED_TIME' => 'Ngày tạo',
    'LBL_SOURCE_INPUT' => 'Nguồn input',
    'LBL_STARRED' => 'Theo dõi',
    'LBL_TAGS' => 'Tags',
    '' => ''
);

$jsLanguageStrings = null;

