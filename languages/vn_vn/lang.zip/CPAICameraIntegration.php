<?php

$languageStrings = Array(
	'CPAICameraIntegration' => 'Tích hợp AI Camera',
	'SINGLE_CPAICameraIntegration' => 'Tích hợp AI Camera',
	'ModuleName ID' => 'Tích hợp AI Camera ID',
);

$jsLanguageStrings = Array();
