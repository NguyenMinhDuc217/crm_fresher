<?php

/* System auto-generated on 2020-04-07 03:20:39 pm.  */

$languageStrings = array(
    'CPChatMessageLog' => 'Lịch sử Chat',
    'SINGLE_CPChatMessageLog' => 'Lịch sử Chat',
    'ModuleName ID' => 'Lịch sử Chat ID',
    'LBL_ADD_RECORD' => 'Thêm Lịch sử Chat',
    'LBL_RECORDS_LIST' => 'Danh sách Lịch sử Chat',
    'LBL_GENERAL_INFORMATION' => 'Thông tin chung',
    'LBL_TRACKING_INFOMATION' => 'Thông tin mô tả',
    'LBL_NAME' => 'Tên',
    'LBL_DESCRIPTION' => 'Mô tả',
    'LBL_MODIFIED_TIME' => 'Ngày sửa',
    'LBL_ASSIGNED_TO' => 'Giao cho',
    'LBL_CREATED_TIME' => 'Ngày tạo',
    'LBL_SOURCE_INPUT' => 'Nguồn input',
    'LBL_STARRED' => 'Theo dõi',
    'LBL_TAGS' => 'Tags',
    'LBL_RELATED_CUSTOMER' => 'Khách hàng',
    'LBL_CHANNEL' => 'Kênh Chat',
    'LBL_CHAT_APP_ID' => 'ID Chat Bot',
    'LBL_CHAT_APP_NAME' => 'Chat Bot',
    'LBL_CONTENT' => 'Nội dung',
);

$jsLanguageStrings = null;

