<?php

/* System auto-generated on 2019-08-08 06:06:53 pm.  */

$languageStrings = array(
    'CPSocialFeedback' => 'Tương tác MXH',
    'SINGLE_CPSocialFeedback' => 'Tương tác MXH',
    'ModuleName ID' => 'Tương tác MXH ID',
    'LBL_ADD_RECORD' => 'Thêm Tương tác MXH',
    'LBL_RECORDS_LIST' => 'Danh sách Tương tác MXH',
    'LBL_GENERAL_INFORMATION' => 'Thông tin chung',
    'LBL_TRACKING_INFOMATION' => 'Thông tin mô tả',
    'LBL_NAME' => 'Tên tương tác',
    'LBL_DESCRIPTION' => 'Mô tả',
    'LBL_MODIFIED_TIME' => 'Ngày sửa',
    'LBL_ASSIGNED_TO' => 'Giao cho',
    'LBL_CREATED_TIME' => 'Ngày tạo',
    'LBL_SOURCE_INPUT' => 'Nguồn input',
    'LBL_STARRED' => 'Theo dõi',
    'LBL_TAGS' => 'Tags',
    'LBL_CPSOCIALFEEDBACK_TYPE' => 'Loại tương tác',
    '' => '',
    'LBL_COMMENT_CONTENTS' => 'Nội dung bình luận',
    'LBL_CPSOCIALFEEDBACK_CHANNEL' => 'Kênh MXH',
    'LBL_CPSOCIALFEEDBACK_CUSTOMER_TYPE' => 'Loại khách hàng',
    'LBL_RELATED_SOCIAL_ARTICLE' => 'Bài viết MXH',
    'LBL_RELATED_CUSTOMER' => 'Người tương tác',
    'LBL_CUSTOMER_TYPE' => 'Loại khách hàng',

    // Added by Phu Vo on 2019.08.22
    'LBL_CONTENT' => 'Nội dung',
    'LBL_RELATED_CAMPAIGN' => 'Chiến dịch',
    'LBL_SOCIAL_HOLDER_ID' => 'ID Trang quản lý MXH',
    'LBL_SOCIAL_HOLDER_NAME' => 'Tên trang quản lý MXH',
    // End Phu Vo
);

$jsLanguageStrings = null;

