<?php

/* System auto-generated on 2021-04-02 06:07:16 pm.  */

$languageStrings = array(
    'CPEmployeeCheckinLog' => 'Lịch sử Checkin Nhân viên',
    'SINGLE_CPEmployeeCheckinLog' => 'Lịch sử Checkin Nhân viên',
    'ModuleName ID' => 'Lịch sử Checkin Nhân viên ID',
    'LBL_ADD_RECORD' => 'Thêm Lịch sử Checkin Nhân viên',
    'LBL_RECORDS_LIST' => 'Danh sách Lịch sử Checkin Nhân viên',
    'LBL_GENERAL_INFORMATION' => 'Thông tin chung',
    'LBL_TRACKING_INFOMATION' => 'Thông tin mô tả',
    'LBL_NAME' => 'Tên',
    'LBL_DESCRIPTION' => 'Mô tả',
    'LBL_MODIFIED_TIME' => 'Ngày sửa',
    'LBL_ASSIGNED_TO' => 'Giao cho',
    'LBL_CREATED_TIME' => 'Ngày tạo',
    'LBL_SOURCE_INPUT' => 'Nguồn input',
    'LBL_STARRED' => 'Theo dõi',
    'LBL_TAGS' => 'Tags',
    'CPEmployee' => 'Nhân viên',
    'LBL_DETECTED_ID' => 'ID nhận diện được',
    'LBL_DETECTED_NAME' => 'Tên nhận diện được',
    'LBL_DETECTED_TIME' => 'Thời điểm nhận diện',
    'LBL_PLACE_NAME' => 'Địa điểm',
    'LBL_DEVICE_ID' => 'ID Thiết bị',
    'LBL_DEVICE_NAME' => 'Tên Thiết bị',
    'LBL_TRACKING_ID' => 'ID Đối soát'
);

$jsLanguageStrings = array(

);

