<?php

$languageStrings = Array(
	'CPMauticIntegration' => 'Tích hợp Mautic',
	'SINGLE_CPMauticIntegration' => 'Tích hợp Mautic',
	'ModuleName ID' => 'Tích hợp Mautic ID',
);