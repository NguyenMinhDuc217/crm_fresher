<?php

/* System auto-generated on 2020-11-09 12:11:54 pm.  */

$languageStrings = array(
    'CPSMSTemplate' => 'Mẫu tin nhắn',
    'SINGLE_CPSMSTemplate' => 'Mẫu tin nhắn',
    'ModuleName ID' => 'Mẫu tin nhắn ID',
    'LBL_ADD_RECORD' => 'Thêm Mẫu tin nhắn',
    'LBL_RECORDS_LIST' => 'Danh sách Mẫu tin nhắn',
    'LBL_GENERAL_INFORMATION' => 'Thông tin chung',
    'LBL_TRACKING_INFOMATION' => 'Nội dung',
    'LBL_NAME' => 'Tên',
    'LBL_DESCRIPTION' => 'Nội dung',
    'LBL_MODIFIED_TIME' => 'Ngày sửa',
    'LBL_ASSIGNED_TO' => 'Giao cho',
    'LBL_CREATED_TIME' => 'Ngày tạo',
    'LBL_SOURCE_INPUT' => 'Nguồn input',
    'LBL_STARRED' => 'Theo dõi',
    'LBL_TAGS' => 'Tags',

    // [SMSCampaign] Added by Hieu Nguyen on 2020-11-09
    'LBL_MESSAGE_TYPE' => 'Loại tin nhắn',
    'sms' => 'SMS',
    'zalo' => 'Zalo',
    // End Hieu Nguyen

    // Added by Hieu Nguyen on 2020-12-07
    'LBL_SELECT_VARIABLE' => 'Chọn biến',
    'LBL_INSERT_VARIABLE' => 'Chèn biến',
    // End Hieu Nguyen

    // [SMSCampaign] Add by Phu Vo on 2020.12.03
    'LBL_CHARACTER_COUNT' => 'Số ký tự',
    // End Phu Vo
);

$jsLanguageStrings = null;

