<?php

/* System auto-generated on 2020-03-04 10:47:28 am.  */

$languageStrings = array(
    'CPMauticContactHistory' => 'Lịch sử contact trên Mautic',
    'SINGLE_CPMauticContactHistory' => 'Lịch sử contact trên Mautic',
    'ModuleName ID' => 'Lịch sử contact trên Mautic ID',
    'LBL_ADD_RECORD' => 'Thêm Lịch sử contact trên Mautic',
    'LBL_RECORDS_LIST' => 'Danh sách Lịch sử contact trên Mautic',
    'LBL_GENERAL_INFORMATION' => 'Thông tin chung',
    'LBL_TRACKING_INFOMATION' => 'Thông tin mô tả',
    'LBL_NAME' => 'Tên',
    'LBL_DESCRIPTION' => 'Mô tả',
    'LBL_MODIFIED_TIME' => 'Ngày sửa',
    'LBL_ASSIGNED_TO' => 'Giao cho',
    'LBL_CREATED_TIME' => 'Ngày tạo',
    'LBL_SOURCE_INPUT' => 'Nguồn input',
    'LBL_STARRED' => 'Theo dõi',
    'LBL_TAGS' => 'Tags',
    'LBL_CPMAUTICCONTACTHISTORY_TYPE' => 'Loại',
    'LBL_LINK' => 'Link',
    'LBL_RELATE_TO' => 'Liên quan tới',
    'asset.download' => 'Asset downloaded',
    'campaign.event' => 'Campaign action triggered',
    'campaign.event.scheduled' => 'Campaign event scheduled',
    'campaign_membership' => 'Campaign membership change',
    'lead.source.created' => 'Contact created by source',
    'lead.source.identified' => 'Contact identified by source',
    'lead.donotcontact' => 'Do not contact',
    'email.failed' => 'Email failed',
    'email.read' => 'Email read',
    'email.replied' => 'Email replied',
    'email.sent' => 'Email sent',
    'form.submitted' => 'Form submitted',
    'lead.imported' => 'Imported',
    'message.queue' => 'Message Queue',
    'page.hit' => 'Page hit',
    'point.gained' => 'Point gained',
    'segment_membership' => 'Segment membership change',
    'stage.changed' => 'Stage changed',
    'sms_reply' => 'Text message received',
    'lead.utmtagsadded' => 'UTM tags recorded',
    'page.videohit' => 'Video view event',
    'LBL_EVENT_TIME' => 'Thời gian',
);

$jsLanguageStrings = null;

