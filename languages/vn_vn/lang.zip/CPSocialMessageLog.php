<?php

/* System auto-generated on 2019-08-15 10:31:03 am.  */

$languageStrings = array(
    'CPSocialMessageLog' => 'Lịch sử gửi tin nhắn MXH',
    'SINGLE_CPSocialMessageLog' => 'Lịch sử gửi tin nhắn MXH',
    'ModuleName ID' => 'Lịch sử gửi tin nhắn MXH ID',
    'LBL_ADD_RECORD' => 'Thêm Lịch sử gửi tin nhắn MXH',
    'LBL_RECORDS_LIST' => 'Danh sách Lịch sử gửi tin nhắn MXH',
    'LBL_GENERAL_INFORMATION' => 'Thông tin chung',
    'LBL_TRACKING_INFOMATION' => 'Thông tin mô tả',
    'LBL_NAME' => 'Tên',
    'LBL_DESCRIPTION' => 'Mô tả',
    'LBL_MODIFIED_TIME' => 'Ngày sửa',
    'LBL_ASSIGNED_TO' => 'Giao cho',
    'LBL_CREATED_TIME' => 'Ngày tạo',
    'LBL_SOURCE_INPUT' => 'Nguồn input',
    'LBL_STARRED' => 'Theo dõi',
    'LBL_TAGS' => 'Tags',
    'LBL_RELATED_CAMPAIGN' => 'Chiến dịch',
    'LBL_RELATED_CUSTOMER' => 'Khách hàng',
    'LBL_CPSOCIALMESSAGELOG_SOCIAL_CHANNEL' => 'Kênh MXH',
    'LBL_SOCIAL_SENDER_ID' => 'Gửi từ ID',
    'LBL_SOCIAL_SENDER_NAME' => 'Gửi từ',
    'LBL_SOCIAL_RECEIVER_IDENTIFIER' => 'Email/Số phone MXH',
    'LBL_SOCIAL_RECEIVER_ID' => 'ID Người nhận trên MXH',
    'LBL_SOCIAL_MESSAGE_TEMPLATE' => 'Mẫu tin nhắn MXH',
    'LBL_CONTENT' => 'Nội dung',
    'LBL_CONTENT_HASH' => 'Mã Hash nội dung',
    'LBL_MESSAGE_TYPE' => 'Loại tin nhắn',
    'LBL_SCHEDULED_SEND_DATE' => 'Ngày bắt đầu gửi',
    'LBL_SCHEDULED_SEND_TIME' => 'Thời gian bắt đầu gửi',
    'LBL_CPSOCIALMESSAGELOG_STATUS' => 'Tình trạng',
    'LBL_ATTEMPT_COUNT' => 'Số lần gửi',
    'LBL_LAST_ATTEMPT_TIME' => 'Lần gửi gần nhất',
    'LBL_SOCIAL_MESSAGE_ID' => 'ID Tin nhắn MXH',
    'zalo' => 'Zalo',
    'facebook' => 'Facebook',
    'queued' => 'Chờ gửi',
    'success' => 'Thành công',
    'failed' => 'Thất bại',
);

$jsLanguageStrings = null;

