<?php
// Added by Hieu Nguyen on 2020-02-28 to customize custom views (saved search list)

$languageStrings = array(
    'LBL_SHARE_TO_ALL_USERS' => 'Tất cả người dùng',
    'LBL_SHARE_TO_SELECTED_USERS' => 'Chỉ định người dùng',
    'LBL_REMOVE_SHARED_FILTER' => 'Gỡ bỏ',
);

$jsLanguageStrings = array(
    'JS_DELETE_FILTER_CONFIRM_MSG' => 'Bạn có chắc muốn xóa hẳn bộ lọc này khỏi hệ thống?',
    'JS_REMOVE_SHARED_FILTER_CONFIRM_MSG' => 'Bạn có chắc muốn gỡ bỏ lọc này khỏi danh sách?',
);