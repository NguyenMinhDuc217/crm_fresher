<?php
$languageStrings = array(
'Not Purchased'	=>	'Not Purchased',
'Purchased'	=>	'Purchased',
);