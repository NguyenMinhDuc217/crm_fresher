<?php
$languageStrings = array(
'Tuần'	=>	'Tuần',
'Người/tháng'	=>	'Người/tháng',
'năm'	=>	'năm',
);