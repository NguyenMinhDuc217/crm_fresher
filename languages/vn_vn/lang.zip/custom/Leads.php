<?php
$languageStrings = array(
'Interactive'	=>	'Interactive',
'dũng vũ'	=>	'dũng vũ',
'vu dung'	=>	'vu dung',
);