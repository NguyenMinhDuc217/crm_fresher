<?php

/* System auto-generated on 2020-11-09 12:03:48 pm.  */

$languageStrings = array(
    'CPSMSOTTMessageLog' => 'Lịch sử gửi tin',
    'SINGLE_CPSMSOTTMessageLog' => 'Lịch sử gửi tin',
    'ModuleName ID' => 'Lịch sử gửi tin ID',
    'LBL_ADD_RECORD' => 'Thêm Lịch sử gửi tin',
    'LBL_RECORDS_LIST' => 'Danh sách Lịch sử gửi tin',
    'LBL_GENERAL_INFORMATION' => 'Thông tin chung',
    'LBL_TRACKING_INFOMATION' => 'Nội dung',
    'LBL_NAME' => 'Tên',
    'LBL_DESCRIPTION' => 'Mô tả',
    'LBL_MODIFIED_TIME' => 'Ngày sửa',
    'LBL_ASSIGNED_TO' => 'Giao cho',
    'LBL_CREATED_TIME' => 'Ngày tạo',
    'LBL_SOURCE_INPUT' => 'Nguồn input',
    'LBL_STARRED' => 'Theo dõi',
    'LBL_TAGS' => 'Tags',
    
    // [SMSCampaign] Added by Hieu Nguyen on 2020-11-09
    'LBL_CREATED_BY' => 'Gửi bởi',
    'LBL_RELATED_CAMPAIGN' => 'Chiến dịch',
    'LBL_RELATED_SMS_OTT_NOTIFIER' => 'Lần gửi',
    'LBL_RELATED_CUSTOMER' => 'Khách hàng',
    'LBL_PHONE_NUMBER' => 'Số điện thoại',
    'LBL_CONTENT' => 'Nội dung',
    'LBL_CONTENT_HASH' => 'Mã Hash nội dung',
    'LBL_MESSAGE_TYPE' => 'Loại tin nhắn',
    'LBL_SCHEDULED_SEND_DATE' => 'Ngày bắt đầu gửi',
    'LBL_SCHEDULED_SEND_TIME' => 'Thời gian bắt đầu gửi',
    'LBL_CPSOCIALMESSAGELOG_STATUS' => 'Tình trạng',
    'LBL_ATTEMPT_COUNT' => 'Số lần gửi',
    'LBL_LAST_ATTEMPT_TIME' => 'Lần gửi gần nhất',
    'LBL_TRACKING_ID' => 'ID Đối soát',
    'sms' => 'SMS',
    'zalo' => 'Zalo',
    'queued' => 'Chờ gửi',
    'dispatched' => 'Đã chuyển',
    'success' => 'Thành công',
    'failed' => 'Thất bại',
    // End Hieu Nguyen
);

$jsLanguageStrings = array(

);

