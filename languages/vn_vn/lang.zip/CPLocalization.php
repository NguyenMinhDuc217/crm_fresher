<?php

$languageStrings = array(
    'CPLocalization' => 'Phân giải địa chỉ',
	'SINGLE_CPLocalization' => 'Phân giải địa chỉ',
);

$jsLanguageStrings = null;