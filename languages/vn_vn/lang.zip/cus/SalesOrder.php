<?php

/*
	System auto-generated on 2021-09-06 06:23:36 pm by admin. 
	THIS FILE IS FOR CUSTOMER TO UPDATE FROM LAYOUT EDITOR. YOU MUST BACKUP THIS FILE TO YOUR PROJECT REPO AND DO NOT MODIFY THIS FILE MANUALLY!!!
*/

$languageStrings = array(
    '-unknown-' => '-unknown-'
);

$jsLanguageStrings = array(

);

