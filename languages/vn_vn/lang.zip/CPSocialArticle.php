<?php

/* System auto-generated on 2020-01-16 11:19:54 am.  */

$languageStrings = array(
    'CPSocialArticle' => 'Bài viết MXH',
    'SINGLE_CPSocialArticle' => 'Bài viết MXH',
    'ModuleName ID' => 'ID Bài viết MXH',
    'LBL_ADD_RECORD' => 'Thêm Bài viết MXH',
    'LBL_RECORDS_LIST' => 'Danh sách Bài viết MXH',
    'LBL_GENERAL_INFORMATION' => 'Thông tin chung',
    'LBL_TRACKING_INFOMATION' => 'Thông tin mô tả',
    'LBL_NAME' => 'Tên',
    'LBL_DESCRIPTION' => 'Mô tả',
    'LBL_MODIFIED_TIME' => 'Ngày sửa',
    'LBL_ASSIGNED_TO' => 'Giao cho',
    'LBL_CREATED_TIME' => 'Ngày tạo',
    'LBL_SOURCE_INPUT' => 'Nguồn input',
    'LBL_STARRED' => 'Theo dõi',
    'LBL_TAGS' => 'Tags',
    'LBL_CPSOCIALARTICLE_TYPE' => 'Loại',
    'LBL_CPSOCIALARTICLE_STATUS' => 'Tình trạng',
    'LBL_IMAGE' => 'Ảnh',
    'LBL_URL' => 'URL',
    'LBL_SOCIAL_ID' => 'ID MXH',
    'LBL_SOCIAL_CHANNEL' => 'Kênh MXH',
    'LBL_SOCIAL_HOLDER_ID' => 'ID Trang quản lý MXH',
    'LBL_SOCIAL_HOLDER_NAME' => 'Tên trang quản lý MXH',
    'LBL_CPSOCIALARTICLELOG_LIST' => 'Lịch sử gửi Bài viết MXH',
    'LBL_CPSOCIALFEEDBACK_LIST' => 'Social Feedback',
    '' => '',
    'LBL_POST_CONTENT' => 'Nội dung bài viết',
    'LBL_CONTENT' => 'Nội dung'
);

$jsLanguageStrings = null;

