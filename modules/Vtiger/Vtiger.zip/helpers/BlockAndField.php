<?php

/*
    Class Vtiger_BlockAndField_Helper
    Author: Hieu Nguyen
    Date: 2019-03-01
    Purpose: provide util functions to sync block and fields between register files and database
*/

require_once('include/utils/FileUtils.php');

class Vtiger_BlockAndField_Helper {

    // Sync form db into register file
    static function syncToRegisterFile($moduleDef) {
        $blocksAndFields = self::getBlocksAndFields($moduleDef['id']);

        // Convert into file format
        $content = [
            'editViewBlocks' => $blocksAndFields['editview_blocks'], 
            'detailViewBlocks' => $blocksAndFields['detailview_blocks'], 
            'fields' => $blocksAndFields['fields']
        ];

        self::writeRegisterFile($moduleDef['name'], $content);
    }

    static function syncBlockToRegisterFile($module, $blockName, $view = 'EditView') {
        global $adb;

        $tableName = ($view == 'EditView') ? 'vtiger_editview_blocks' : 'vtiger_blocks';
        $sql = "SELECT * FROM {$tableName} WHERE tabid = ? AND blocklabel = ?";
        $result = $adb->pquery($sql, [$module->id, $blockName]);

        $blockDef = $adb->fetchByAssoc($result);
        $blockDef = self::trimBlockDef($blockDef);

        self::writeBlockToRegisterFile($module->name, $blockDef, $view);
    }

    static function syncFieldToRegisterFile($module, $fieldName) {
        global $adb;

        $sql = "SELECT * FROM vtiger_field WHERE tabid = ? AND fieldname = ?";
        $result = $adb->pquery($sql, [$module->id, $fieldName]);
        $fieldDef = $adb->fetchByAssoc($result);

        $fieldDef = self::attachBlocksName($fieldDef);
        $fieldDef = self::trimFieldDef($fieldDef);

        self::writeFieldToRegisterFile($module->name, $fieldDef);
    }

    static function removeBlockFromRegisterFile($moduleName, $blockName, $blockType = 'EditView') {
        $content = self::readRegisterFile($moduleName);

        if(empty($content)) return;

        if($blockType == 'EditView') {
            unset($content['editViewBlocks'][$blockName]);
        }
        else {
            unset($content['detailViewBlocks'][$blockName]);
        }

        self::writeRegisterFile($moduleName, $content);
    }

    static function removeFieldFromRegisterFile($moduleName, $fieldName) {
        $content = self::readRegisterFile($moduleName);

        if(empty($content)) return;

        unset($content['fields'][$fieldName]);
        self::writeRegisterFile($moduleName, $content);
    }

    // Sync from register file into db
    static function syncToDatabase($moduleDef) {
        $moduleName = $moduleDef['name'];
        $moduleId = $moduleDef['id'];
        $moduleModel = Vtiger_Module_Model::getInstance($moduleName);
        $content = self::readRegisterFile($moduleName);
        $blocksAndFieldsMap = self::getBlocksAndFieldsMap($moduleId);

        // Sync EditView Blocks
        foreach($content['editViewBlocks'] as $blockDef) {
            // if($blockDef['blocklabel'] == 'LBL_BLOCK1') {
            //     $debug = 1;
            // }

            $block = $blocksAndFieldsMap['editview_blocks'][$blockDef['blocklabel']];

            // Re-assign module id and tab id
            $blockDef['blockid'] = !empty($block) ? $block['blockid'] : ''; // New block will not exist in the map
            $blockDef['tabid'] = $moduleId;
            $blockDef['table_name'] = 'vtiger_editview_blocks';

            $blockId = self::syncBlockToDb($blockDef);

            // Insert new block into the map
            if(empty($block)) {
                $block = $blockDef;
                $block['blockid'] = $blockId;
                $blocksAndFieldsMap['editview_blocks'][$blockDef['blocklabel']] = $block;
            }
        }

        // Sync DetaiView Blocks
        foreach($content['detailViewBlocks'] as $blockDef) {
            // if($blockDef['blocklabel'] == 'LBL_BLOCK1') {
            //     $debug = 1;
            // }

            $block = $blocksAndFieldsMap['detailview_blocks'][$blockDef['blocklabel']];

            // Re-assign module id and tab id
            $blockDef['blockid'] = !empty($block) ? $block['blockid'] : ''; // New block will not exist in the map
            $blockDef['tabid'] = $moduleId;
            $blockDef['table_name'] = 'vtiger_blocks';

            $blockId = self::syncBlockToDb($blockDef);

            // Insert new block into the map
            if(empty($block)) {
                $block = $blockDef;
                $block['blockid'] = $blockId;
                $blocksAndFieldsMap['detailview_blocks'][$blockDef['blocklabel']] = $block;
            }
        }

        // Sync Fields
        $createdFields = [];

        foreach($content['fields'] as $fieldDef) {
            // if($fieldDef['fieldname'] == 'field1') {
            //     $debug = 1;
            // }

            $field = $blocksAndFieldsMap['fields'][$fieldDef['fieldname']];
            $editViewBlock = $blocksAndFieldsMap['editview_blocks'][$fieldDef['editview_block_name']];
            $detailViewBlock = $blocksAndFieldsMap['detailview_blocks'][$fieldDef['detailview_block_name']];
            
            // Re-assign module id, field id and block id
            $fieldDef['tabid'] = $moduleId;
            $fieldDef['fieldid'] = !empty($field) ? $field['fieldid'] : ''; // New field will not exist in the map
            $fieldDef['editview_block'] = $editViewBlock['blockid'];
            $fieldDef['block'] = $detailViewBlock['blockid'];

            $result = self::syncFieldToDb($fieldDef, $detailViewBlock, $moduleModel);

            // Log created fields
            if($result == 2) {
                $fieldName = $fieldDef['fieldname'];
                
                if(in_array($fieldDef['uitype'], [15, 16])) {
                    $fieldName .= " (picklist)";
                }

                if($fieldDef['uitype'] == 33) {
                    $fieldName .= " (multi-picklist)";
                }
                
                $createdFields[] = $fieldName;
            }
        }

        return $createdFields;
    }

    private static function syncBlockToDb($blockDef) {
        $block = new Vtiger_Block();
        $block->initialize($blockDef);
        $block->blockTableName = $blockDef['table_name'];

        if(!$block->module) {
            return;
        }

        // Update exsiting block
        if($block->id) {
            global $adb;

            $sql = "UPDATE {$blockDef['table_name']} SET sequence = ? WHERE blockid = ?";
            $params = [$blockDef['sequence'], $block->id];

            $adb->pquery($sql, $params);
        }
        // Create new block
        else {
            $block->id = $block->__create($block->module);
        }

        return $block->id;
    }

    private static function syncFieldToDb($fieldDef, $detailViewBlockDef, $moduleModel) {
        global $adb, $dbconfigoption;
        $field = new Vtiger_Field_Model();
        $field->initialize($fieldDef);

        // Re-apply meta data for EditView
        $field->editview_block_id = $fieldDef['editview_block'];
        $field->editview_sequence = $fieldDef['editview_sequence'];
        $field->editview_presence = $fieldDef['editview_presence'];

        $result = 0;

        // Update existing field
        if($field->id) {
            $sql = "UPDATE vtiger_field
                SET block = ?, presence = ?, sequence = ?, editview_block = ?, editview_sequence = ?, editview_presence = ?, displaytype = ?, 
                    typeofdata = ?, defaultvalue = ?, isunique = ?, readonly = ?, quickcreate = ?, masseditable = ?, summaryfield = ?, headerfield = ?
                WHERE fieldid = ?";
            $params = [
                $fieldDef['block'], $fieldDef['presence'], $fieldDef['sequence'], $fieldDef['editview_block'], $fieldDef['editview_sequence'], $fieldDef['editview_presence'], $fieldDef['displaytype'],
                $fieldDef['typeofdata'], $fieldDef['defaultvalue'], $fieldDef['isunique'], $fieldDef['readonly'], $fieldDef['quickcreate'], $fieldDef['masseditable'], $fieldDef['summaryfield'], $fieldDef['headerfield'],
                $field->id
            ];

            $adb->pquery($sql, $params);
            $result = 1;
        }
        // Create new field
        else {
            $block = new Vtiger_Block();
            $block->initialize($detailViewBlockDef);

            // In case no block to contain this field in DetailView
            if(!$block->id) {
                $block->module = $moduleModel;
            }

            $field->__create($block);
            $result = 2;
        }

        // Init picklist and multi-piclist field
        if(in_array($field->uitype, [15, 16, 33])) {
            $field->setPicklistValues('');

            // Create picklist sequence table if it is not exists
            $sequenceTableName = sprintf($dbconfigoption['seqname_format'], "vtiger_{$field->name}");

            if(!Vtiger_Utils::CheckTable($sequenceTableName)) {
                $adb->database->CreateSequence($sequenceTableName);
            }
        }
        
        // Clearing cache
        Vtiger_Cache::flushModuleandBlockFieldsCache($moduleModel, $field->getBlockId());

        return $result;
    }

    private static function readRegisterFile($moduleName) {
        $file = self::getRegisterFile($moduleName);
        include($file);

        $content = [
            'editViewBlocks' => $editViewBlocks, 
            'detailViewBlocks' => $detailViewBlocks, 
            'fields' => $fields
        ];

        return $content;
    }

    private static function writeBlockToRegisterFile($moduleName, $blockDef = [], $blockType = 'EditView') {
        $content = self::readRegisterFile($moduleName);

        if($blockType == 'EditView') {
            $content['editViewBlocks'][$blockDef['blocklabel']] = $blockDef;
        }
        else {
            $content['detailViewBlocks'][$blockDef['blocklabel']] = $blockDef;
        }
        
        self::writeRegisterFile($moduleName, $content);
    }

    private static function writeFieldToRegisterFile($moduleName, $fieldDef = []) {
        $content = self::readRegisterFile($moduleName);
        $content['fields'][$fieldDef['fieldname']] = $fieldDef;
        self::writeRegisterFile($moduleName, $content);
    }

    private static function writeRegisterFile($moduleName, $content) {
        $file = self::getRegisterFile($moduleName);
        FileUtils::writeArrayToFile($content, $file, 'DANGER! DO NOT EDIT THIS FILE!!!!');
    }

    static function getRegisterFile($moduleName) {
        return "modules/{$moduleName}/BlocksAndFieldsRegister.php";
    }

    static function getEntityModules() {
        global $adb;

        $sql = "SELECT tabid AS id, name FROM vtiger_tab WHERE isentitytype = 1 OR name = 'Users'";
        $result = $adb->pquery($sql);
        $entityModules = [];

        while($row = $adb->fetchByAssoc($result)) {
            $entityModules[$row['name']] = $row;
        }

        return $entityModules;
    }

    // Return a map by name
    private static function getBlocksAndFieldsMap($moduleId) {
        global $adb;

        $editViewBlocksMap = [];
        $detailViewBlocksMap = [];
        $fieldsMap = [];

        // Get EditView Blocks
        $sql = "SELECT * FROM vtiger_editview_blocks WHERE tabid = ?";
        $result = $adb->pquery($sql, [$moduleId]);

        while($row = $adb->fetchByAssoc($result)) {
            $editViewBlocksMap[$row['blocklabel']] = $row;
        }

        // Get DetailView Blocks
        $sql = "SELECT * FROM vtiger_blocks WHERE tabid = ?";
        $result = $adb->pquery($sql, [$moduleId]);

        while($row = $adb->fetchByAssoc($result)) {
            $detailViewBlocksMap[$row['blocklabel']] = $row;
        }

        // Get Fields
        $sql = "SELECT * FROM vtiger_field WHERE tabid = ?";
        $result = $adb->pquery($sql, [$moduleId]);

        while($row = $adb->fetchByAssoc($result)) {
            $fieldsMap[$row['fieldname']] = $row;
        }

        $map = [
            'editview_blocks' => $editViewBlocksMap, 
            'detailview_blocks' => $detailViewBlocksMap,
            'fields' => $fieldsMap
        ];

        return $map;
    }

    private static function getBlocksAndFields($moduleId) {
        global $adb;

        $editViewBlocksMap = [];
        $detailViewBlocksMap = [];
        $blocksAndFields = [
            'editview_blocks' => [],
            'detailview_blocks' => [],
            'fields' => [],
        ];

        // Get EditView Blocks
        $sql = "SELECT * FROM vtiger_editview_blocks WHERE tabid = ?";
        $result = $adb->pquery($sql, [$moduleId]);

        while($row = $adb->fetchByAssoc($result)) {
            $editViewBlocksMap[$row['blockid']] = $row;
            $blocksAndFields['editview_blocks'][$row['blocklabel']] = self::trimBlockDef($row);
        }

        // Get DetailView Blocks
        $sql = "SELECT * FROM vtiger_blocks WHERE tabid = ?";
        $result = $adb->pquery($sql, [$moduleId]);

        while($row = $adb->fetchByAssoc($result)) {
            $detailViewBlocksMap[$row['blockid']] = $row;
            $blocksAndFields['detailview_blocks'][$row['blocklabel']] = self::trimBlockDef($row);
        }

        // Get Fields
        $sql = "SELECT * FROM vtiger_field WHERE tabid = ?";
        $result = $adb->pquery($sql, [$moduleId]);

        while($row = $adb->fetchByAssoc($result)) {
            // Save column type to be able to re-create the correct column type when repair
            $row['columntype'] = self::getColumnType($row['tablename'], $row['columnname']);

            $editViewBlock = $editViewBlocksMap[$row['editview_block']];
            $detailViewBlock = $detailViewBlocksMap[$row['block']];
            $row['editview_block_name'] = $editViewBlock['blocklabel'];
            $row['detailview_block_name'] = $detailViewBlock['blocklabel'];
            $blocksAndFields['fields'][$row['fieldname']] = self::trimFieldDef($row);
        }

        return $blocksAndFields;
    }

    private static function getColumnType($tableName, $columnName) {
        global $adb;
        $sql = "SHOW COLUMNS FROM {$tableName} WHERE FIELD = '{$columnName}'";
        $result = $adb->pquery($sql, []);
        $columnInfo = $adb->fetchByAssoc($result);

        return $columnInfo['type'];
    }

    // Attach edit view and detail view blocks name into the field def before writing into register file
    private static function attachBlocksName($fieldDef) {
        global $adb;

        $sql = "SELECT blocklabel FROM vtiger_editview_blocks WHERE blockid = ?";
        $fieldDef['editview_block_name'] = $adb->getOne($sql, [$fieldDef['editview_block']]);

        $sql = "SELECT blocklabel FROM vtiger_editview_blocks WHERE blockid = ?";
        $fieldDef['detailview_block_name'] = $adb->getOne($sql, [$fieldDef['block']]);

        return $fieldDef;
    }

    // Remove unnecessary block data before writing into register file
    private static function trimBlockDef($blockDef) {
        unset($blockDef['tabid']);
        unset($blockDef['blockid']);

        return $blockDef;
    }

    // Remove unnecessary field data before writing into register file
    private static function trimFieldDef($fieldDef) {
        unset($fieldDef['tabid']);
        unset($fieldDef['fieldid']);
        unset($fieldDef['block']);
        unset($fieldDef['editview_block']);

        return $fieldDef;
    }
}