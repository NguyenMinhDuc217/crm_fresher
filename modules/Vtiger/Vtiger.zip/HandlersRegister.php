<?php

// Added by Hieu Nguyen on 2020-09-28 to register event handlers
$registeredEvents = array(
    'vtiger.entity.beforesave',
    'vtiger.entity.aftersave',
    'vtiger.entity.beforedelete',
    'vtiger.entity.afterdelete',
    'vtiger.entity.beforerestore',
    'vtiger.entity.afterrestore',
);

$handlerName = 'GlobalEventHandler';